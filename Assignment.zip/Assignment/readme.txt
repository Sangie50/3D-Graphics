https://unsplash.com/photos/vS3idIiYxX0 - wall

https://www.myfreetextures.com/wp-content/uploads/2014/10/texture-seamless-wood-5.jpg - floor

labs - egg (diffuse and specular)

https://unsplash.com/photos/eB1ziPSixlQ - spotlight

https://www.freepik.com/free-photo/solid-navy-blue-concrete-textured-wall_17119118.htm#page=1&query=dark%20blue%20texture&position=9&from_view=keyword - base

https://unsplash.com/photos/PvgBUx3ih2k - robot

